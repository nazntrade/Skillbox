package ru.zhdanon.skillcinema.ui.intro

import androidx.recyclerview.widget.RecyclerView
import ru.zhdanon.skillcinema.databinding.IntroItemPageBinding

class IntroViewHolder(val binding: IntroItemPageBinding) : RecyclerView.ViewHolder(binding.root)