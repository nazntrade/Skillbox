package ru.zhdanon.skillcinema.ui.staffdetail.adapter

import androidx.recyclerview.widget.RecyclerView
import ru.zhdanon.skillcinema.databinding.ItemFilmographyFilmBinding

class FilmographyViewHolder(val binding: ItemFilmographyFilmBinding) :
    RecyclerView.ViewHolder(binding.root)