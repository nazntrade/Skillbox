package ru.zhdanon.skillcinema.ui.allfilmsbycategory.allfilmadapter

import androidx.recyclerview.widget.RecyclerView
import ru.zhdanon.skillcinema.databinding.ItemFilmBinding

class AllFilmViewHolder(val binding: ItemFilmBinding) : RecyclerView.ViewHolder(binding.root)