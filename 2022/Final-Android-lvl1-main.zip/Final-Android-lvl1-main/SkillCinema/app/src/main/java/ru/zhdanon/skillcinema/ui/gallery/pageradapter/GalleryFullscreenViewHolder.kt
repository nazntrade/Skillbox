package ru.zhdanon.skillcinema.ui.gallery.pageradapter

import androidx.recyclerview.widget.RecyclerView
import ru.zhdanon.skillcinema.databinding.ItemGalleryFullscreenBinding

class GalleryFullscreenViewHolder(val binding: ItemGalleryFullscreenBinding) :
    RecyclerView.ViewHolder(binding.root)