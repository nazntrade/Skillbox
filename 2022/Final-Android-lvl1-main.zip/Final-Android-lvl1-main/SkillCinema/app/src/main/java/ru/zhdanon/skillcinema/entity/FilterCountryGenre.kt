package ru.zhdanon.skillcinema.entity

interface FilterCountryGenre {
    val id: Int
    val name: String
}