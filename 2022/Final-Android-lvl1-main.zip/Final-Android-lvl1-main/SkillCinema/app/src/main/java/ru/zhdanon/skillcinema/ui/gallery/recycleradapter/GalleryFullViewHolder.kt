package ru.zhdanon.skillcinema.ui.gallery.recycleradapter

import androidx.recyclerview.widget.RecyclerView
import ru.zhdanon.skillcinema.databinding.ItemGalleryImageBinding

class GalleryFullViewHolder(val binding: ItemGalleryImageBinding) :
    RecyclerView.ViewHolder(binding.root)