package ru.zhdanon.skillcinema.ui.search.adapter

import androidx.recyclerview.widget.RecyclerView
import ru.zhdanon.skillcinema.databinding.ItemSearchFiltersBinding

class SearchFiltersViewHolder(val binding: ItemSearchFiltersBinding) :
    RecyclerView.ViewHolder(binding.root)