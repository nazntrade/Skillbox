package ru.zhdanon.skillcinema.ui.profile

import androidx.fragment.app.Fragment

class FragmentProfile : Fragment() {
}