# Budget your finances!
💰This application can help you to account your personal income and expenses.
Final diploma project for Skillbox course.

## Stack
* UIKit
* Realm 
* UserDefaults
* Charts

## Screenshots
![alt text](Screenshots/image1.png "Revenue tab (Main)")![alt text](Screenshots/image2.png "Purchases categories tab")
![alt text](Screenshots/image3.png "Purchases by category screen")![alt text](Screenshots/image4.png "Purchases on graph screen")
![alt text](Screenshots/image5.png "Total Revenue and purchases graph tab")
