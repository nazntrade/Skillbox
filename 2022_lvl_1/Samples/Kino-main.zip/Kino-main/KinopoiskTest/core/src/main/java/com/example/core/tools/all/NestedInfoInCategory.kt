package com.example.core.tools.all

interface NestedInfoInCategory