package com.example.core.tools.base_model.category

import com.example.core.tools.category.CategoryInfo

interface BaseCategory {
    val category: CategoryInfo
}