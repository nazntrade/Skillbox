package com.example.core.tools.category

enum class TypeSettings(val hint:String, val title: String){
    COUNTRY("Введите страну ","Страна"),
    GENRE("Введите жанр","Жанр")
}