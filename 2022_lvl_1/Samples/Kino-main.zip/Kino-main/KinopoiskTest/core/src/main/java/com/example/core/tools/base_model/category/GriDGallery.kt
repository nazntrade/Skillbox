package com.example.core.tools.base_model.category

import com.example.core.tools.base_model.BaseGallery

class GriDGallery(
    override val imageUrl: String,
    override val previewUrl: String

) : BaseGallery