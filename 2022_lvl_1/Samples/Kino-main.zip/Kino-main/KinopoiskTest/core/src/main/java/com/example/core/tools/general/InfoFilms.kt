package com.example.core.tools.general

interface InfoFilms