package com.example.core.tools.all

import android.os.Parcelable
import kotlinx.android.parcel.Parcelize

@Parcelize
class CategoryFilms:Parcelable {
    /** МАГИЯ!!! этот файл ни где не учасствует, но если удалить данный файл то все крашится */
}
