package com.example.core.tools.base_model


class FullGalleryImage(
    override val imageUrl: String,
    override val previewUrl: String
) : BaseGallery