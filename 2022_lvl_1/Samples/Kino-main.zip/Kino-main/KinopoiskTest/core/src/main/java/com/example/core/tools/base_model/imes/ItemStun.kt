package com.example.core.tools.base_model.imes

import com.example.core.tools.all.NestedInfoInCategory

class ItemStun:NestedInfoInCategory
class ItemNext:NestedInfoInCategory