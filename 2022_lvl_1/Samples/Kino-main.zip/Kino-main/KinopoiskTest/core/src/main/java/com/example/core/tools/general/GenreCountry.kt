package com.example.core.tools.general

import com.example.core.tools.all.NestedInfoInCategory

interface GenreCountry:NestedInfoInCategory {
    val info: String
    val id: Int
}