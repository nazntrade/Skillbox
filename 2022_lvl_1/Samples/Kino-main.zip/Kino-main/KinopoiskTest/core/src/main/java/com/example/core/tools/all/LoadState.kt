package com.example.core.tools.all

enum class LoadState {
    LOADING,NOT_RESULT,SUCCESS,ERROR, FHF
}