package com.example.core.tools.base_model

import com.example.core.tools.all.NestedInfoInCategory

class FilmsCollection(

    val id: Int? = null,
    val nameCollection: String,
    var size: Int = 0,
    var isCheck: Boolean
): NestedInfoInCategory