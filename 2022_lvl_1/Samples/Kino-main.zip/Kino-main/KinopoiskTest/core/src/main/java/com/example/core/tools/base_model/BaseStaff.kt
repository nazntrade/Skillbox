package com.example.core.tools.base_model

interface BaseStaff {
    val staffId: Int
}