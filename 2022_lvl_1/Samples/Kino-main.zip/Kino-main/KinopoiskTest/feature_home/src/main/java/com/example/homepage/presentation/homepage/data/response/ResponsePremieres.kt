package com.example.homepage.presentation.homepage.data.response

import com.example.homepage.presentation.homepage.data.films.dto.PremieresDTO

class ResponsePremieres(
    val items: List<PremieresDTO>,
)