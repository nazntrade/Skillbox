package com.example.homepage.presentation.homepage.data.response

import com.example.homepage.presentation.homepage.data.films.dto.PopularDTO

 class ResponsePopular(
     val films: List<PopularDTO>,
)