package com.example.feaure_onboarding.data

class ListOnBoarding(
    val text:String,
    val id: Int
)