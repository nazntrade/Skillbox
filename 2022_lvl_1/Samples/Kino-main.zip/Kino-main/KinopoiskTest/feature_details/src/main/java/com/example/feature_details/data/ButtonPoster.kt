package com.example.feature_details.data

enum class ButtonPoster{
    LIKE,FAVORITE,LOOK
}