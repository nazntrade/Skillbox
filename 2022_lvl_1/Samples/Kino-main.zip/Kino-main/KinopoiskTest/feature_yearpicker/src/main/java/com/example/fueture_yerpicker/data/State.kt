package com.example.fueture_yerpicker.data

enum class State {
    SELECT, NOT_SELECT
}