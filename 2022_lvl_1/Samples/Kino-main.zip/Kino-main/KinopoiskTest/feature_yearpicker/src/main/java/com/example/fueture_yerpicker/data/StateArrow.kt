package com.example.fueture_yerpicker.data

enum class StateArrow {
    NEXT, BACK, NOT_NAVIGATE
}