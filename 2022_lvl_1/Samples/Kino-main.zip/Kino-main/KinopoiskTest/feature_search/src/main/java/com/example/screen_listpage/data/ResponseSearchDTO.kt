package com.example.screen_listpage.data

data class ResponseSearchDTO(
    val items: List<SearchFilmDTO>,
)