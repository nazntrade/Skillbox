package com.example.adapterdelegate.data

class ResponseSimilar(
    val items: List<SimilarFilmsDTO>,
)